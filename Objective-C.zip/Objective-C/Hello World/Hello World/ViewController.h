//
//  ViewController.h
//  Hello World
//
//  Created by zhhz on 14-10-15.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    UILabel *statusText;
}


@property(nonatomic,retain) IBOutlet UILabel *statusText;

-(IBAction)buttonPressed:(id)sender;


@end
