//
//  ViewController.m
//  test_06
//
//  Created by zhhz on 14/10/19.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize button1;
@synthesize button2;
@synthesize button3;
@synthesize button4;
@synthesize button5;
@synthesize button6;

//-(BOOL)shouldAutorotate{
    //return yes;
//}
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration{
    //if(UIInterfaceOrientationIsPortrait)
}


- (void)viewDidLoad {
    //if(interfaceOri
    button1.frame=CGRectMake(20, 20, 125, 125);
    button2.frame=CGRectMake(175, 20, 125, 125);
    button3.frame=CGRectMake(20, 168, 125, 125);
    button4.frame=CGRectMake(175, 168, 125, 125);
    button5.frame=CGRectMake(20, 315, 125, 125);
    button6.frame=CGRectMake(175, 315, 125, 125);
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
