//
//  Header.h
//  test_07
//
//  Created by zhhz on 14/10/26.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#ifndef test_07_Header_h
#define test_07_Header_h


#endif
#import <UIKit/UIKit.h>

@interface Blue_alert : UIViewController

-(void)showOkayCancelAlert;
-(IBAction)buttonpressed;

@end