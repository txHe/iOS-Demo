//
//  RSS.h
//  RSS
//
//  Created by zhhz on 14/11/27.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <Cocoa/Cocoa.h>

@interface GameAppRecord : NSObject

@property (nonatomic,retain) NSString *name;
@property (nonatomic,retain) NSString *price;
@property (nonatomic,retain) NSString *thumbImageURLString;
@property (nonatomic,retain) NSString *largeImageURLString;
@property (nonatomic,retain) UIImage *imgThumbl;


@end