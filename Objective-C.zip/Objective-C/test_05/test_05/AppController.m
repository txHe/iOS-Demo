//
//  AppController.m
//  test_05
//
//  Created by zhhz on 14-10-14.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import "AppController.h"

@implementation AppController
-(id)init
{
    if(self=[super init])
    {
        NSLog(@"init:text %@ / results %@",textField,resultsField);
    }
    return self;
}

-(void)awakeFromNib
{
    NSLog(@"awake:text %@ / results %@",textField,resultsField);
    [textField setStringValue:@"Enter text here"];
    [resultsField setStringValue:@"Results"];
}

-(IBAction)uppercase:(id)sender
{
    NSString *original;
    original=[textField stringValue];
    
    NSString *uppercase;
    uppercase=[original uppercaseString];
    
    [resultsField setStringValue:uppercase];
}
-(IBAction)lowercase:(id)sender
{
    NSString *original;
    original=[textField stringValue];
    
    NSString *lowercase;
    lowercase=[original lowercaseString];
    
    [resultsField setStringValue:lowercase];
}


@end
