//
//  ViewController.m
//  demo_02
//
//  Created by zhhz on 14/11/18.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property(nonatomic,retain) IBOutlet  UIButton *button;
@property(nonatomic,retain) IBOutlet  UITextField *textfield;

@end

@implementation ViewController


//警报
-(BOOL)IsPureInt:(NSString *)string
{
    NSScanner* scan = [NSScanner scannerWithString:string];
    
    int val;
    
    return[scan scanInt:&val] && [scan isAtEnd];
    //return [scan scanInt:&val];
}

- (IBAction)clickButton:(id)sender
{
    NSString *word=self.textfield.text;
    bool flag1=[self IsPureInt:word];
    bool flag2=[word isEqualToString:@""];
    if (flag2|(!flag1)) {
        //UIAlertView *myAlertView=[[UIAlertView alloc] initWithTitle:@"请重新输入" message:@"输入内容不能为空且输入码只能为数字" //delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        //[myAlertView show];
        UIAlertController *myAlertView=[UIAlertController alertControllerWithTitle:@"请重新输入" message:@"输入内容不能为空且输入码只能为数字" preferredStyle:UIAlertControllerStyleAlert];
        [myAlertView addAction:[UIAlertAction actionWithTitle:@"Action1" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            self.textfield.text=nil;
        }]];
        [self presentViewController:myAlertView animated:YES completion:nil];
    }
    for(int i=0;i<[word length];i++)
    {
        unichar c =[word characterAtIndex:i];
        if (c >=0x4E00 && c <=0x9FFF)
        {
            printf("汉字");
        }
        else
        {
            printf("英文");
        }
    }
}

/*
-(void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    //这里你自己补充吧，你可以再弹出一个ActionSheet或者什么，whatever，who cares?
    if(buttonIndex==[alertView cancelButtonIndex])
        self.textfield.text=nil;
    else
        self.textfield.text=nil;
}

//操作表
/*
-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==[actionSheet destructiveButtonIndex])
        //这里捕捉“毁灭键”,其实该键的index是0，从上到下从0开始，称之为毁灭是因为是红的
    {
        //点击该键后我们再弹出一个AlertView
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"AlertView的标题" message:@"我是一个AlertView" delegate:self cancelButtonTitle:@"取消键" otherButtonTitles:@"随手加", nil];
        //这是弹出的一个与当前View无关的，所以显示不用showIn，直接show
        [myAlertView show];
    }
}
*/
/*
- (IBAction)clickButton:(id)sender {
    UIActionSheet *myActionSheet=[[UIActionSheet alloc]initWithTitle:@"标题" delegate:self cancelButtonTitle:@"取消键" destructiveButtonTitle:@"毁灭键" otherButtonTitles:@"额外加键", nil];
    //这样就创建了一个UIActionSheet对象，如果要多加按钮的话在nil前面直接加就行，记得用逗号隔开。
    //下面是显示，注意ActioinSheet是出现在底部的，是附加在当前的View上的，所以我们用showInView方法
    [myActionSheet showInView:self.view];
    
}*/


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
