//
//  AppDelegate.h
//  Hello World
//
//  Created by zhhz on 14-10-15.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    UIWindow *window;
    ViewController *viewController;
}


@property (nonatomic,retain) IBOutlet UIWindow *window;
@property (nonatomic,retain) IBOutlet ViewController *viewController;


@end
