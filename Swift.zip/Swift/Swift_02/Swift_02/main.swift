//
//  main.swift
//  Swift_02
//
//  Created by zhhz on 15/1/18.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//

import Foundation

println("Hello, World!")

/*-----------------------------复杂数据类型-----------------------------*/

/*-----------------------------数组-----------------------------*/

/*
数组是由一个或多个相同类型的元素按照有序或无序的排列在一起的数据集合。数组使用有序列表可以存储相同类型的多重数据，相同的值可以多次出现在
一个数组的不同位置
Objective-C拥有NSArray和NSMutableArray两个类来管理数组数据，它们可以存储任何数据类型的实例而且不用提供它们返回对象的任何本质信息。但是在Swift
语言中，数据被存储进入某个数组之前，类型必须明确，且与数组其他元素类型相同，可以通过显式的类型声明或类型推断来做的这一点。标准格式：
*/

//[类型]()
var emptyArray=[String]()

var ExceptionTypes=["none","warning","error"]//省略类型的数组声明
ExceptionTypes[0]="it's safe"//访问并修改其中的元素
//ExceptionTypes[3]="gron"//数组越界fatal error:Array index out of range

//正式的声明格式：
var ArraryName=Array<String>()

//在它的定义中，我们可以看到实现了两个版本的subscript(下标访问和区间访问)，第一个版本使得可以使用安全范围的下标访问数组中对应的元素，
//第二个则是获取slice
//subscript(index:Int)->T
//subscript(subRange:Range<Int>)->Slice<T>
var BrazilTeamMembers=[String]()
BrazilTeamMembers.append("six")
BrazilTeamMembers.insert("one", atIndex: 0)

//BrazilTeamMembers+= "seven"
BrazilTeamMembers.isEmpty
BrazilTeamMembers[1]="Neymar"
BrazilTeamMembers.count
BrazilTeamMembers.removeAtIndex(2)//删除下标为2的元素
BrazilTeamMembers.removeLast()//删除最好一个元素
BrazilTeamMembers.removeAll(keepCapacity: true)//删除所有元素

//我们也可以使用加法操作符“+”来组合两个相同类型数组，新数组的数据类型会从两个数组的数据类型中推断出来
var addStringArr=ExceptionTypes+BrazilTeamMembers

//可使用两个关键字来声明一个二维数组
var mutlArr=Array<Array<Int>>()

/*
C语言中，数组名通常是指向数组首元素的指针，通常代表的是数组第一个元素的首地址，数组中每个元素对应一段内存空间。而Swift与C不同，Swift语言的数组是
值类型的，不管时是赋值还是当作参数传递，都只是维护它的拷贝。
*/

/*-----------------------------字典-----------------------------*/

/*
字典用于存储无序的数据元素值，它可以存储任何类型的元素，你甚至可以将数组作为字典的元素，字典的每个值都有一个唯一的标示符“key"，（有时也被称为键或者下标），通过”key“来管理并维护字典中数据，这种引用机制也被称为”键值对“。创建字典的标准格式是：
字典名称={字典关键字}Dictionary<type,type>()
*/
var emptyDictionary=Dictionary<String,Int>()
//和数组一样，字典也有多种操作方法，依然有增删改查 updateValue

/*-----------------------------结构体-----------------------------*/

struct BookInfo {
    var ID:Int=0
    var Name:String="Default"
    var Author:String="Default"
    var RootType:String="Default"
    var SubType:String="Default"
    var Position:String="0-0-0-0"
}


































