// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var str1="hello my first code"

println("hello")

