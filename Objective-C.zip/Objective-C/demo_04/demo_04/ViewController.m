//
//  ViewController.m
//  demo_04
//
//  Created by zhhz on 14/12/1.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textfield1;
@property (weak, nonatomic) IBOutlet UITextField *textfield2;
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@property (nonatomic,assign) NSInteger numofsets;
@property (nonatomic,retain) NSData *tempZdy;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableview.delegate=self;
    self.tableview.dataSource=self;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSLog(@"----mytableview numberofsectionsintableview===");
    
    
    
    return 1;
}
-(void)readZdy{
    NSError *Error;
    NSString *Data = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"ZdySim" ofType:@"txt"]encoding:NSUTF8StringEncoding error:&Error];
    self.tempZdy=Data;
}

//返回某个section的行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"----mytableview numberOfRowsInSection===");
    NSInteger row;
    row=self.numofsets;
    return row;
}

//返回某一行的cell(即设置每行调用的cell)
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSLog(@"======mytableviewcontroller cellforrowatindexpath");
    
    //========================================
    NSString * myIdentifier = @"myidentifier";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:myIdentifier];//获取一个可重用的表单元
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:myIdentifier];//创建一个
    }
    
    int i;
    
    /*
    NSArray *keyArray=[self.tempdic allKeys];
    NSArray *valueArray=[self.tempdic allValues];
    
    NSInteger num=self.tempdic.count;
    for(i=0;i<num;i++)
    {
        if(indexPath.row==i)
        {
            NSString *s1=[keyArray objectAtIndex:i];
            NSString *s2=[valueArray objectAtIndex:i];
            NSString *s=[s1 stringByAppendingFormat:@"      %@",s2];
            
            cell.textLabel.text=s;
            
            //cell.accessoryType = UITableViewCellStyleDefault;
        }
        
    }*/
    return cell;
}



@end
