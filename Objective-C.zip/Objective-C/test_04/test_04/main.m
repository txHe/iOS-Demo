//
//  main.m
//  test_04
//
//  Created by zhhz on 14-10-13.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        NSLog(@"Hello world!!!");
        NSFileManager *manager;
        manager=[NSFileManager defaultManager];
        
        //z
        NSString *home;
        home=[@"~" stringByExpandingTildeInPath];
        
        NSDirectoryEnumerator *direnum;
        direnum=[manager enumeratorAtPath:home];
        
        NSMutableArray *files;
        files=[NSMutableArray arrayWithCapacity:42];
        
        NSString *filename;
        while(filename=[direnum nextObject]){
            if([[filename pathExtension]isEqualTo:@"jpg"])
                [files addObject:filename];
        }
        NSEnumerator *fileenum;
        fileenum=[files objectEnumerator];
        
        while (filename=[fileenum nextObject]) {
            NSLog(@"%@",filename);
        }
    }
    return 0;
}

