//
//  main.m
//test_02

  //Created by zhhz on 14-10-11.
  //Copyright (c) 2014年 zhhz. All rights reserved.


#import <Cocoa/Cocoa.h>

@interface Tire : NSObject{
        int size;
}
@property (nonatomic,readwrite) int size;


@end



@implementation Tire

@synthesize size;

@end


int main(int argc, const char * argv[]) {
        @autoreleasepool {
        NSLog(@"Hello, World!");
        //NSArray只能存储objective-c的对象，而不能存储C语音中的基本数据类型，如int,float,enum,struct或NSArray中的随机指针
        NSArray *array;
        array=[NSArray arrayWithObjects:@"one",@"two",@"three", nil];
        int i;
        for(i=0;i<[array count];i++)
        {
            NSLog(@"index %d has %@",i,[array objectAtIndex:i]);
        }
        NSString *string=@"oop:ack:bork:greeble:ponies";
        NSArray *chunks=[string componentsSeparatedByString:@":"];
        string=[chunks componentsJoinedByString:@":-)"];
        NSLog(@"%@",string);
        
        //可变数组
        NSMutableArray *brray;
        brray=[NSMutableArray arrayWithCapacity:50];
        
        for(i=0;i<4;i++){
            Tire *tire=[Tire new];
            [brray addObject:tire];
        }
        for (i=0; i<4; i++) {
            Tire * t;
            t=[brray objectAtIndex:i];
            t.size=i;
            NSLog(@"%d",t.size);
        }
        [brray removeObjectAtIndex:1];
        for (i=0; i<3; i++) {
            Tire * m;
            m=[brray objectAtIndex:i];
            NSLog(@"%d",m.size);
        }

    }
    return 0;
}
