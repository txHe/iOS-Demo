//
//  main.m
//  test_03
//
//  Created by zhhz on 14-10-13.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface Tire:NSObject{
    int size;
}

@property (nonatomic,readwrite) int size;

@end

@implementation Tire

@dynamic size;

@end
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSMutableArray *array;
        array=[NSMutableArray arrayWithCapacity:20];
        int i;
        for (i=0; i<4; i++) {
            Tire *tire =[Tire new];
            [array addObject:tire];
        }
        //请求枚举器
        NSEnumerator *enumerator;
        enumerator=[array objectEnumerator];
        id thingie;
        while (thingie=[enumerator nextObject]) {
            NSLog(@"I found %@",thingie);
        }
        //快速枚举 这个循环体将会遍历数组中的每个元素，并且用变量string存储每个数组的值
        for(NSString *string in array)
        {
            NSLog(@"I found %@",string);
        }
        
        Tire *t1=[Tire new];
        Tire *t2=[Tire new];
        Tire *t3=[Tire new];
        Tire *t4=[Tire new];
        
        NSDictionary *tires;
        tires=[NSDictionary dictionaryWithObjectsAndKeys:t1,@"font-left",t2,@"font-right",t3,@"back-left",t4,@"back-right", nil];
        Tire *tire=[tires objectForKey:@"back-right"];
        NSLog(@"%@",t4);
        NSLog(@"%@",tire);
        
        //NSNumber
        NSMutableDictionary *dictionary;
        NSNumber *number;
        number=[NSNumber numberWithInt:42];
        [array addObject:number];
        [dictionary setObject:number forKey:@"Bork"];
        
        NSRect rect=NSMakeRect(1, 2, 30, 40);
        NSValue *value;
        value=[NSValue valueWithBytes:&rect objCType:@encode(NSRect)];
        [array addObject:value];
    
        value=[array objectAtIndex:5];
        [value getValue:&rect];
        
        NSLog(@"Hello, World!");
         NSLog(@"%@",value);
        
        
        [dictionary setObject:[NSNull null] forKey:@"home fax machine"];
        NSLog(@"%@",[dictionary objectForKey:@"home fax machine"]);
        
        id homefax;
        homefax=[dictionary objectForKey:@"home fax machine"];
        if (homefax == [NSNull null]) {
            NSLog(@"you win");
        }
    }
    return 0;
}
