//
//  CollectionViewController.swift
//  SwiftUI_06
//
//  Created by zhhz on 15/1/21.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//

import UIKit

let reuseIdentifier = "Cell"

class CustomLayout: UICollectionViewLayout{
    override func collectionViewContentSize() -> CGSize {
        return CGSizeMake(collectionView!.bounds.size.width, collectionView!.bounds.size.height)
    }
    
    override func layoutAttributesForElementsInRect(rect: CGRect) -> [AnyObject]? {
        var attributesArray = [AnyObject]()
        
        let cellCount = self.collectionView!.numberOfItemsInSection(0)
        
        for var i = 0 ; i < cellCount; ++i{
            var indexPath = NSIndexPath(forItem: i, inSection: 0)
            
            var attributes = self.layoutAttributesForItemAtIndexPath(indexPath)
            
            attributesArray.append(attributes)
        }
        return attributesArray
    }
    
override func layoutAttributesForItemAtIndexPath(indexPath: NSIndexPath) -> UICollectionViewLayoutAttributes! {
        var attribute = UICollectionViewLayoutAttributes(forCellWithIndexPath: indexPath)
        
        //单元格外部空隙
        //let itemSpacing = 2
        //let lineSpacing = 5
        
        //单元格边长
        let Key_Height:Float = (Float(162 - 30)) / 5
        let Key_Width_Small:Float = (Float(self.collectionView!.frame.width - 20.0)) / 8
        let Key_Width_Large:Float = Key_Width_Small * 2
        
        //内部间隙
        var insets = UIEdgeInsetsMake(3, 2, 3, 2) //左右2，上下3
        
        
        //每行5个button
        var line:Int = indexPath.item / 5
        
        //当前行的Y坐标
        var lineOriginY = Key_Height * Float(line) + Float(insets.top)
        
        //右侧单元格x坐标，这里按左右对齐，所以中间空隙大
        
        
        //if indexPath.item == 0{
            attribute.frame = CGRectMake(insets.left, CGFloat(lineOriginY),CGFloat(Key_Width_Small), CGFloat(Key_Height))
        //}
        
        return attribute
    }
}



class CollectionViewController:UIViewController,UICollectionViewDataSource,UICollectionViewDelegate{

    //let courses = [["name":"Swift","pic":"Swift.png"],["name":"ObjectC","pic":"ObjectC.png"],["name":"java","pic":"java.png"],["name":"php","pic":"php.png"]]
    let courses = ["hello"]
    
    var collectionView : UICollectionView!
    //var layout = UICollectionViewLayout()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let layout = CustomLayout()
        
        
        self.collectionView = UICollectionView(frame: self.view.frame,collectionViewLayout: layout)

        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
             
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        
        self.collectionView.registerClass(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        
        self.collectionView.backgroundColor = UIColor.grayColor()
        self.view.addSubview(collectionView)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        //#warning Incomplete method implementation -- Return the number of sections
        return 1
    }


    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //#warning Incomplete method implementation -- Return the number of items in the section
        return courses.count
    }

    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        //let identify:String = "DesignViewCell"
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(reuseIdentifier, forIndexPath: indexPath) as UICollectionViewCell
    
        var button:UIButton = UIButton.buttonWithType(UIButtonType.System) as UIButton
        button.layer.cornerRadius = 4.0
        button.frame = cell.frame
        
        button.setTitle(courses[indexPath.item], forState: .Normal)
        button.setTitleColor(UIColor.blackColor(), forState: .Normal)
        
        button.backgroundColor = UIColor.whiteColor()
        
        cell.addSubview(button)
        //(cell.contentView.viewWithTag(1) as UIImageView).image = UIImage(named:courses[indexPath.item]["pic"]!)
        // Configure the cell
        //(cell.contentView.viewWithTag(2) as UILabel).text = courses[indexPath.item]["name"]
        return cell
    }

    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(collectionView: UICollectionView, shouldHighlightItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(collectionView: UICollectionView, shouldSelectItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(collectionView: UICollectionView, shouldShowMenuForItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return false
    }

    override func collectionView(collectionView: UICollectionView, canPerformAction action: Selector, forItemAtIndexPath indexPath: NSIndexPath, withSender sender: AnyObject?) -> Bool {
        return false
    }

    override func collectionView(collectionView: UICollectionView, performAction action: Selector, forItemAtIndexPath indexPath: NSIndexPath, withSender sender: AnyObject?) {
    
    }
    */

}
