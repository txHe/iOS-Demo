//
//  AppDelegate.h
//  demo_04
//
//  Created by zhhz on 14/12/1.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

