// Playground - noun: a place where people can play

import UIKit

class Person{
    //类属性、方法
    var name:String!
}

var p = Person()

println(p)

class Student{
    var name:String = ""        //变量属性
    var classno:Int = 0
    var from:String = ""
    let country:String = "中国" //常量属性
}

var student = Student()

student.name = "HTX"
student.classno = 1
student.from = "NanTong"

println("\(student.name) \(student.classno) \(student.from)")

//存储属性——用来表示类的一个特性。
//计算属性——不直接存储特性，提供的是一个计算后的结果。

/*------存储特性-------*/

//强制解包可选：

class StudentOptional{
    var name:String!
    var classno:Int!
    var from:String!
    let country:String = "china"
    let friend:Person = Person()
}

var studentOptional = StudentOptional()
studentOptional.name = "HTX"
studentOptional.classno = 2
studentOptional.from = "RuGao"

//studentOptional.country = "中国"

studentOptional.friend.name = "HeTianXiong"


class Deposit{
    init(){
        println("init at deposit")
    }
}

class PersonLazy {
    var name:String!
    lazy var money:Deposit = Deposit()
}

class StudentLazy{
    var name:String!
    var classno:Int!
    var from:String!
    let country:String = "china"
    let friend:PersonLazy = PersonLazy()
}

var studentlazy = StudentLazy()
studentlazy.name = "HTX"
studentlazy.classno = 1
studentlazy.from = "suzhou"
studentlazy.friend.name = "huhu"


class Calculator {
    var a:Int = 1
    var b:Int = 1
    init(a:Int,b:Int){
        self.a = a
        self.b = b
    }
    
    func sum()->Int {
        return a + b
    }
    
    func quotient()->Int{
        return a/b
    }
    
    func product()->Int{
        return a * b
    }
    
    func difference()->Int {
        return a - b
    }
}

class PCalculator {
    var a:Int = 1
    var b:Int = 1
    var sum:Int{
        return a + b
    }
    
    var difference:Int{
        return a - b
    }
    
    var product:Int{
        return a * b
    }
    
    var quotient:Int {
        return a/b
    }
    init(a:Int,b:Int){
        self.a = a
        self.b = b
    }
    var scale:Int{
        get{
            return a/a
        }
        set{
            a = a * newValue
            b = b * newValue
        }
    }
}

var pcal = PCalculator(a: 30, b: 10)
pcal.scale = 3
println("\(pcal.sum)    \(pcal.quotient)    \(pcal.product)   \(pcal.difference)")


var label:UILabel!
var stype:String! //显示最高分还是分数

var score:Int = 0{
    didSet{
        //分数变化，标签内容也变化
        label.text = "\(stype):\(score)"
    }
}

class Teacher {
    var name:String!
    var classno:Int!
    var from:String!
    class var country:String{
        return "中国"
    }
}

println(Teacher.country)






