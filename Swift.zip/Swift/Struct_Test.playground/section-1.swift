// Playground - noun: a place where people can play

import UIKit

/*
类和结构体的对比：

1.共同点

定义属性用于储存值
定义方法用于提供功能
定义下标用于下标语法访问值
定义初始化器用于生成初始化值
通过扩展以增加默认实现的功能
符合协议以对某类提供标准功能

2.不同点

继承允许一个类继承另一个类的特征
类型转换允许在运行时检查和解释一个类实例的类型
取消初始化器允许一个类实例释放任何其所被分配的资源
引用计数允许对一个类的多次引用

PS：结构体总是通过被复制的方式在代码中传递，因此请不要使用引用计数

结构体是结构化程序编程的产物，类是面向对象的产物。

结构体是由零个或多个类型相同或不相同的数据组合而成的数据集合，其中的数据或者方法被称为它的成员或成员方法

成员包括
1、属性
2、类型别名
3、数组
4、其他结构体或枚举声明

*/

//创建一个用于存储书籍信息的结构体

struct BookInfo {
    var ID:Int = 0
    var Name:String = "Default"
    var Author:String = "Default"
    var RootType:String = "Default"
    var SubType:String = "Default"
    var Position:String = "0-0-0-0"
    
}

//创建一个默认构造器创建一个结构体实例
var ProgramGuide:BookInfo

//调用逐一构造器创建一个结构体实例

var BeautyMath = BookInfo(ID: 0021, Name: "The Beauty Math", Author: "JunMu", RootType: "It", SubType: "Math", Position: "E6-3-7-687")
BeautyMath.Name = "Jun Wu"

//需要注意的是，结构体是值类型的，其实例会在被赋予常量和被函数调用时被复制

var DayBookType = BeautyMath.RootType
DayBookType = "Language"

println("\(BeautyMath.RootType)")
//修改变量DayBookType的值不会影响BeautyMath.RootType的值

//类是引用类型
//与值类型不同，引用类型在被赋予到一个变量，常量或者被传递到一个函数时，操作的并不是其拷贝，因此，引用的是已存在的实例本身而不是其拷贝。

class BookInfoClass {
    var ID:Int = 0
    var Name:String = "Default"
    var Author:String = "Default"
    var RootType:String = "Default"
    var SubType:String = "Default"
    var Position:String = "0-0-0-0"
}

let SwiftGuide = BookInfoClass()
SwiftGuide.ID = 222
SwiftGuide.Name = "SwiftGuide"
SwiftGuide.Author = "somebody"

println("\(SwiftGuide.ID)   \(SwiftGuide.Name)  \(SwiftGuide.Author)")

let anotherSwiftGuide = SwiftGuide
anotherSwiftGuide.ID = 333

//最后查看两个类的ID值可知，都为333，虽然声明为常量，常量本身不会改变，但它们不存储这个BookInfoClass实例，在后台仅仅是对它的引用，所以赋值改变的是被引用基础上ID参数而不是常量的值。

//恒等运算符

//因为类时引用类型，有可能有多个常量和变量在后台同时引用某一个类实例。（对于结构体和枚举来说，这并不成立，因为它们作值类型，在被赋予常量，变量或者传递到函数时，总是会被拷贝）

//Swift内建了两个恒等运算符：等价于（===）和不等价于(!==)
if SwiftGuide === anotherSwiftGuide {
    println("refer to the same instance.")
}






