//
//  ViewController.m
//  demo_01
//
//  Created by zhhz on 14/11/17.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic,retain) IBOutlet UITextView *textview;
@property (nonatomic,retain) IBOutlet UILabel *label;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSError *Error;
    NSString *Data = [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"纵横手机输入法协议v01" ofType:@"txt"]encoding:NSUTF8StringEncoding error:&Error];
    //NSString *dataUTF8 = [Data stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];//转UTF-8编码
    NSString *dataGBK = [Data stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding ];//转GBK
    
    NSArray *Lines = [Data componentsSeparatedByString:@"\n"];
    self.label.text=@"纵横输入法用户服务协议";
    self.textview.text=dataGBK;
    NSLog(@"%@",dataGBK);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
