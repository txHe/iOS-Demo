//
//  TableViewController.swift
//  SwiftUI_04
//
//  Created by zhhz on 15/1/19.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//

import UIKit
class save_read {
    func saveData(){
        var defaults:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        defaults.setObject("HTX", forKey: "name")
        defaults.setObject("man", forKey: "sex")
        defaults.setObject("22", forKey: "age")
        
        defaults.synchronize()
    }
    
    func readData(){
        var defaults:NSUserDefaults = NSUserDefaults.standardUserDefaults()
        var name:String = defaults.stringForKey("name")!
        var sex:String = defaults.stringForKey("sex")!
        var age:String = defaults.stringForKey("age")!
        
        println("name=\(name) sex=\(sex) age=\(age)")
        
    }
}
class TableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var choose = save_read()
    let s=5
    
    //choose.saveData()
    //choose.readData()
    
    var tableView:UITableView?
    
    var ctrls = ["UILabel","UIButtom","UIImageView","UISlider","UIWebView"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Swift description"
        self.tableView = UITableView(frame: self.view.frame, style: UITableViewStyle.Plain)
        
        self.tableView!.delegate = self
        self.tableView!.dataSource = self
        self.tableView!.registerClass(UITableViewCell.self, forCellReuseIdentifier: "SwiftCell")
        self.view.addSubview(self.tableView!)
        
        choose.saveData()
        choose.readData()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return self.ctrls.count
    }

    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("SwiftCell", forIndexPath: indexPath) as UITableViewCell
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        cell.textLabel!.text = self.ctrls[indexPath.row]
        
        // Configure the cell...

        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.tableView!.deselectRowAtIndexPath(indexPath, animated: true)
        
        var detailViewController = selectViewController()
        detailViewController.title = self.self.ctrls[indexPath.row]
        self.navigationController!.pushViewController(detailViewController, animated: true)
    }

    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return NO if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

}
