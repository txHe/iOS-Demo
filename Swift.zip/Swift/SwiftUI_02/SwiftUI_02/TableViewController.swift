//
//  ViewController.swift
//  SwiftUI_02
//
//  Created by zhhz on 15/1/19.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//

import UIKit

class TableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var ctrlnames=[String]()
    
    var tableView:UITableView?
    
    override func loadView() {
        super.loadView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.ctrlnames = NSArray (contentsOfFile: NSBundle.mainBundle().pathForResource("Controls", ofType: "plist")!) as Array
        self.ctrlnames=NSArray(objects: "happy","sad") as Array
        println(self.ctrlnames)

        //创建表视图
        
        self.tableView = UITableView(frame: self.view.frame, style: UITableViewStyle.Plain)
        self.tableView!.delegate = self
        self.tableView!.dataSource = self
        //
        self.tableView!.registerClass(UITableViewCell.self, forCellReuseIdentifier: "SwiftCell")
        self.tableView!.addSubview(self.tableView!)
        
       /* var headerLabel = UILabel(frame: CGRectMake(0, 0 , self.view.bounds.size.width, 30))
        headerLabel.backgroundColor = UIColor.blackColor()
        headerLabel.textColor = UIColor.whiteColor()
        headerLabel.numberOfLines = 0
        headerLabel.lineBreakMode = NSLineBreakMode.ByWordWrapping
        headerLabel.text = "常见UIKit控件"
        headerLabel.font = UIFont.italicSystemFontOfSize(20)
        self.tableView!.tableHeaderView = headerLabel*/
        
        self.navigationItem.title="纵横输入法"
    }
    
    //分区个数
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    //返回表格行数
    func tableView(tableView: UITableView , numberOfRowsInSection section: Int)->Int{
        return self.ctrlnames.count
    }
    //创建各单元显示内容（创建参数indexPath指定的单元）
    func tableView(tableView: UITableView , cellForRowAtIndexPath indexPath:NSIndexPath)->UITableViewCell{
        //为提高显示姓名，已创建完成的单元需重复使用
        let identify:String = "SwiftCell"
        
        //同一形式单元格重复使用
        let cell = tableView.dequeueReusableCellWithIdentifier(identify , forIndexPath:indexPath) as UITableViewCell
        
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        
        cell.textLabel?.text = self.ctrlnames[indexPath.row]
        return cell
    }
    
    func tableView(tableView: UITableView, didDeselectRowAtIndexPath indexPath: NSIndexPath) {
        self.tableView!.deselectRowAtIndexPath(indexPath, animated: true)
        
        var itemString = self.ctrlnames[indexPath.row]
        
        var alertview = UIAlertView()
        alertview.title = "提示"
        alertview.message = "你选中了【\(itemString)】"
        alertview.addButtonWithTitle("确定")
        alertview.show()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

