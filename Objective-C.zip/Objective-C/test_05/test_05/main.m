//
//  main.m
//  test_05
//
//  Created by zhhz on 14-10-14.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
