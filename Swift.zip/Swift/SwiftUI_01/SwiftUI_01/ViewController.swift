//
//  ViewController.swift
//  SwiftUI_01
//
//  Created by zhhz on 15/1/19.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    var uiswitch:UISwitch!;
    override func viewDidLoad() {
        super.viewDidLoad()
        var label=UILabel(frame: CGRectMake(10, 20, 300, 100))
        label.text="hello everyone"
        label.textColor=UIColor.whiteColor()
        label.backgroundColor=UIColor.blackColor()
        self.view.addSubview(label)
        var button:UIButton=UIButton.buttonWithType(UIButtonType.ContactAdd) as UIButton
        button.frame=CGRectMake(10, 150, 100, 30)
        button.setTitle("按钮",forState:UIControlState.Normal)
        self.view.addSubview(button)
        button.addTarget(self, action:Selector("tapped"), forControlEvents: UIControlEvents.TouchUpInside)
        uiswitch=UISwitch()
        uiswitch.center=CGPointMake(100, 50)
        uiswitch.on=true
        uiswitch.addTarget(self, action: Selector("switchDidChange"), forControlEvents: UIControlEvents.ValueChanged)
        self.view.addSubview(uiswitch)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func switchDidChange(){
        println(uiswitch.on)
    }
    
    
    func tapped(){
        println("tapped")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

