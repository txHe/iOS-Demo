//
//  RSS.m
//  RSS
//
//  Created by zhhz on 14/11/27.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RSS.h"

@implementation GameAppRecord

@synthesize name=_name;
@synthesize price=_price;
@synthesize thumbImageURLString=_thumbImageURLString;
@synthesize largeImageURLString=_largeImageURLString;
@synthesize imgThumbl=_imgThumbl;


@end


-(NSString *)description
{
    return [NSString stringWithFormat:@"\nAPPRecord:[%@]\n[%@]\n[%@]\n[%@]"];
}
