//
//  main.swift
//  swift_01
//
//  Created by zhhz on 15/1/18.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//

import Foundation

println("Hello, World!")

/*---------------------------变量与常量---------------------------*/

var str:String="hello world"

str="1024"

let constr="i love my contry"
//constr="2048"会编译报错，不能修改常量

println(str)
println(constr)

/*---------------------------整型和浮点型---------------------------*/

var sampleInteger:Int
var tmpInteger=12

//显示声明如下
var tmpInterger=Int.init(12)

var tmpDouble:Double
var sampleValue=1.68

var DoubleValue=2+sampleValue//类型被推断为浮点型

/*---------------------------布尔型---------------------------*/

var KeyValue=false

//通过调用description属性输出字符值false
println(KeyValue.description)

/*---------------------------字符串和字符---------------------------*/

var sampleStr:String

var keyNote="some note"

if !keyNote.isEmpty{
    println(keyNote)
}

//字符串操作只需要简单地通过“+"号将两个字符串相连即可
sampleStr=keyNote+" is not null"

println(sampleStr)

//由于Unicode字符集的特性，我们不能通过确定每个字符的字长，一些以前常用的方式都需要改变，其中最直接的影响是，我们在Swift中不能直接的将字符串
//当作字符数组那样通过使用下标访问指定字符，但是查看String的定义我们可以看到，其实它时实现了下标访问方法的：

//subscript(i:String.Index)->Character{ get }
/*
String.Index结构体的定义
extension String : CollectionType {
    struct Index : BidirectionalIndexType, Comparable, Reflectable {
    func successor() -> String.Index
    func predecessor() -> String.Index
    func getMirror() -> MirrorType
    }
    var startIndex: String.Index { get }
    var endIndex: String.Index { get }
    subscript (i: String.Index) -> Character { get }
    func generate() -> IndexingGenerator<String>
}
*/
var s="1234567890"

let index = advance(s.startIndex, 5)
let index2 = advance(s.endIndex, -6)//倒数

var range = Range<String.Index>(start: index2,end: index)

var s1:String=s.substringFromIndex(index)
var s2:String=s.substringToIndex(index2)
var s3=s.substringWithRange(range)

println("s1=="+s1)//67890
println("s2=="+s2)//1234
println("s3=="+s3)//5

//Swift语言支持字符串插值，可以在长字符串中插入常量、变量、字面量和表达式，而不用经过特殊的转换，这使得创建用于展示、存储和打印的自定义字符串变得轻松自如
let gameName="2048"

println("hello my program name is \(gameName)")

//与其他数据类型相同，可以声明String类型的常量，也可以声明String类型的变量，在Swift语言中，声明为变量就可以被修改。
//Swift语言使用值传递作为默认字符串拷贝方式，无论何时，传递的都将是值得拷贝。

//由于全面支持Unicode字符，每一个字符值代表一个Unicode字符，在Swift语言中表示字符使用character类型。

var myChar:Character="$"

let LogTitle="Swift is a new object-oriented programming language for ios and osx development."

println("LogTitle has \(countElements(LogTitle))")//推荐使用countElement函数来获取字符串的数量

/*
1、连接两个字符串只需要用“+”号即可
2、比较两个字符串是否相等可以使用“==”操作符，如果两个字符串包含字符相同、顺序相同则比较结果为true
String类型的hasPrefix/hasSuffix方法检查字符串是否拥有特定的前缀/后缀
String类型还拥有uppercaseString和lowercaseString
*/

//字符串输出
var pepoles=3

println(String(pepoles))//强制类型转换

/*---------------------------可选（optional)---------------------------*/

//Swift语言为我们提供了一种全新的、更加安全的类型-可选类型，通过查看可选类型的定义，我们可以知道，其实可选类型时使用范型枚举的形式来组织的

/*case None
case Some(T)
可选是指当一个变量、常量或者其他类中存储有值的时候返回里面存储的值（即Some(T))，没有值的时候返回nil(即None）。
这里使用了范型，也就是说此特性可以运用于所有的类型、结构体、类或者其他复杂数据类型。可选的标准声明方式是在程序中使用类型名紧跟“？”，例如：
*/

var roundValue:Int?

println("The round Value is \(roundValue?.description)")

//上述的标准声明方式其实也是一种省略形式的语法糖，也可以使用真正的显式的声明方式：
//var optionalValue:Optional<Int>

//可选是一种十分强大的类型安全机制，在实际编码过程当中，经常会使用一种叫做可选绑定(optional binding)的方式来保证安全的unwarp，如下例所示：

var optionalValue:Optional<Int>

if var MaxValue = optionalValue{//若optionalValue则不执行下面语句，从而避免了因为使用值为nil的对象导致的程序异常
    MaxValue += 1
    println("The convert Value is \(MaxValue)")
}

/*
Attention:
1、在Objective-C中nil表示的是一个指向不存在对象的指针，而Swift中表示空得关键字位"nil",它没有其他含义
2、可选类型的变量或者常量在有值的时候返回值，没有值的时候不会返回任何东西，包括false
3、nil不能用于非可选的常量或者变量，如果你的代码中可能会出现没有值的情况，请务必声明其位可选类型。
*/

//在某些程序架构中，在特定模块中可以确定某个可选变量总是有值的，这种时候就可以使用隐式解析可选，隐式解析可选用于一个确定会有值得可选类型实例声明
//可以将可选类型变量声明中得”？“改为”！“来标注一个隐式解析可选
let nullValue:String!="Not null String"

println(nullValue)

var succedCreateClass:Int?
var feedBack=1

var returnValue=succedCreateClass ?? feedBack//??为可选操作符，执行逻辑：当运算符当操作数a为nil时表达式返回操作数b的值，如果a不为nil则返回a的值

/*---------------------------元组---------------------------*/

//可以通过使用元组把多个不同类型的值组合在一起，组合成一个复合值，这样可以使代码更具可读性和更多的可能性。
let (appType,appName)=("game","2048")//一个匿名的元组

println("i have \(appType),it's names \(appName)")

let myProject=(oneElement:"game",twoElement:2048)

/*---------------------------类型别名---------------------------*/

typealias ShortInteger = Int8

/*---------------------------断言---------------------------*/

/*
一套程序中80%的代码都是在做异常处理的工作，另外20%才是我们功能实现部分。其实这80%主要就是为了提升程序的健壮性（软件产品质量指标之一），也就是程序在发生
错误后的继续运行的能力，在以往我们都是通过异常处理来完成的。

计算机程序的错误通常分为语法错误和逻辑错误，语法错误通常在编译阶段的解释器中就会给予我们提示，但是逻辑错误往往隐藏在最不起眼的地方。除了学会良好的代码编写规范，
我们还可以使用一些特别的方式来捕捉可能出现的错误，可以使用断点调试或者"try-catch"之类的方式判断并修复它。但是，一些偶发（甚至无数次运行才会出现一次）的错误单靠
断点之类的方式是很难排除掉的。为此，为大家引入一个不是很常用的调试工具函数：assert。
*/

var UseDate = -1

assert(UseDate<=0, "超出预期，不能启动程序")//当UseDate大于0时……





























