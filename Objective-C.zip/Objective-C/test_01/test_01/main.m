//
//  main.m
//  test_01
//
//  Created by zhhz on 14-10-10.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <Cocoa/Cocoa.h>

typedef struct NSRange
{
    unsigned int location;
    unsigned int length;
};

typedef struct NSRect{
    NSPoint orgin;
    NSSize  size;
};


//+(id) stringWithFormat:(NSString *)format,...;stringWithFormat定义
//实例方法要用前导减号（-）来声明，这些方法将会在某个对象实例中运行，比如获取一个Ciecle的颜色或者一个Tire的气压。
 //如果某方法用来实现常规功能，比如创建一个实例对象或者访问一些全局类数据，那么最好使用前导加号（+）他将声明为类方法
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSRange range=NSMakeRange(17, 4);
        NSLog(@"%d,%d",range.location,range.length);
        NSLog(@"Hello, World!");
        NSRect rect;
        int x,y,h,w;
        x=rect.origin.x=1;
        y=rect.origin.y=2;
        h=rect.size.height=5;
        w=rect.size.width=10;
        NSLog(@"%d,%d,%d,%d",x,y,h,w);
        NSString *height;
        height=[NSString stringWithFormat:@"Your height is %d feet,%d inches",5,11];
        //关于大小
        unsigned int length=[height length];
        if([height length]>15){
            NSLog(@"wow,you're really tall!");
        }
        //比较的策略
        NSString *thing1=@"hello 5";
        NSString *thing2;
        thing2=[NSString stringWithFormat:@"hello %d",5];
        if([thing1 isEqualToString:thing2]){
            NSLog(@"They are the same!");
        }
        //compare:将接收对象和传递来的字符串逐个字符进行比较，它返回一个NSComparisonReasult(enum类型)来显示比较结果
        if([thing1 compare:thing2]==NSOrderedSame)
        {
            NSLog(@"They are the same!");
        }
        //不区分大小写比较
        if([thing1 compare:thing2 options:NSCaseInsensitiveSearch | NSNumericSearch]==NSOrderedSame){
            NSLog(@"They match!");
        }
        //判断字符串内是否还包含其他字符串
        NSString *filename=@"draft-chapters.pages";
        if([filename hasPrefix:@"draft"]){
            NSLog(@"this is a draft!");
        }
        if([filename hasSuffix:@".mov"])
        {
            NSLog(@"this is a movie!");
        }
        NSRange range1;
        range1=[filename rangeOfString:@"chapter"];
        if(range1.location!=NSNotFound)
        {
            NSLog(@"%d,%d",range1.location,range1.length);
        }
        //可变性
        NSMutableString *string;
        string=[NSMutableString stringWithCapacity:42];
        [string appendString:@"Hello there "];
        [string appendFormat:@"human %d",39];
        NSLog(@"%@",string);
        
        NSMutableString *friends;
        friends=[NSMutableString stringWithCapacity:50];
        [friends appendString:@"James BethLynn Jack Evan"];
         NSLog(@"%@",friends);
        
        NSRange jackRange;
        jackRange=[friends rangeOfString:@"Jack"];
        jackRange.length++;
        
        [friends deleteCharactersInRange:jackRange];
        NSLog(@"%@",friends);
    }
        return 0;
}