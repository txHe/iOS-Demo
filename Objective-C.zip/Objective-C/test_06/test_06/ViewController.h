//
//  ViewController.h
//  test_06
//
//  Created by zhhz on 14/10/19.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UIButton *button1;
    UIButton *button2;
    UIButton *button3;
    UIButton *button4;
    UIButton *button5;
    UIButton *button6;
}

@property(nonatomic,retain) IBOutlet UIButton *button1;
@property(nonatomic,retain) IBOutlet UIButton *button2;
@property(nonatomic,retain) IBOutlet UIButton *button3;
@property(nonatomic,retain) IBOutlet UIButton *button4;
@property(nonatomic,retain) IBOutlet UIButton *button5;
@property(nonatomic,retain) IBOutlet UIButton *button6;

@end

