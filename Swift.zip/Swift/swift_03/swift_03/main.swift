//
//  main.swift
//  swift_03
//
//  Created by zhhz on 15/1/18.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//

import Foundation

var string=NSString(format: "%@ %@", "hello","world")

string=string.lowercaseString

string=string.stringByReplacingOccurrencesOfString("world", withString: "swift")

println(string)

var string1 = NSString(string: "123")

var num=(string1 as String).toInt()

println(num)

let string2:NSString="Apple,ios,swift,String"

let subStringsArray=string2.componentsSeparatedByString(",")

for sub:AnyObject in subStringsArray{
    println(sub)
}