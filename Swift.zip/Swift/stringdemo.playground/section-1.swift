// Playground - noun: a place where people can play

import UIKit
import Foundation

var str:NSString = "01231425"

if String(str.characterAtIndex(1)) == "_"   {
    println("hello")
}
var a:[String] = ["0","1","2"]

a.insert("3", atIndex: 1)

var s = "12334"

var f:Bool = s.hasPrefix("2334")

var t:NSMutableString = "1"

var c:Character = "c"

t.appendString(String(c))

var planetype:Int = 1
if planetype == 1{
    println("ok")
}

var sss = str.substringToIndex(5) 

Int(str.characterAtIndex(0))
