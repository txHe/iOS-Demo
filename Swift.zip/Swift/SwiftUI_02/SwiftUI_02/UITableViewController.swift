//
//  UITableView.swift
//  SwiftUI_02
//
//  Created by zhhz on 15/1/19.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//


/*import UIKit

class ViewController:UIViewController,UITableViewsDataSource,UITableViewDelegate {
    var ctrlnames:String[]
    var tableView:UITableView
    
    override func loadView(){
        super.loadView()
    }
    override func ViewController(){
        super.viewDidLoad()
    }
    
    
}*/