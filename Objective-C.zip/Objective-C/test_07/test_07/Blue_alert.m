//
//  Blue_alert.m
//  test_07
//
//  Created by zhhz on 14/10/26.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Blue_alert.h"


@implementation Blue_alert

-(void)showOkayCancelAlert
{
    NSString *title=NSLocalizedString(@"A Short Title IS Best",nil);
    NSString *message=NSLocalizedString(@"A message should be a short,complete sentence.", nil);
    NSString *cancelButtonTitle=NSLocalizedString(@"cancel", nil);
    NSString *otherButtonTitle=NSLocalizedString(@"OK", nil);
    
    UIAlertController *alertController=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    
    //create the actions
    UIAlertAction *cancelAction=[UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction *action){
        NSLog(@"The \"Okay/Cancel\"alert's cancel action occured.");
    }];
    UIAlertAction *otherAction=[UIAlertAction actionWithTitle:otherButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        NSLog(@"The \"Okay/Cancel\"alert's other action occured.");
    }];
    
    UIAlertAction *otherAction1=[UIAlertAction actionWithTitle:otherButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        NSLog(@"The \"Okay/Cancel\"alert's other action occured.");
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:otherAction];
    [alertController addAction:otherAction1];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

-(void)buttonpressed
{
    [self showOkayCancelAlert];
}
@end