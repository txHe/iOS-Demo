//
//  CollectionViewController.swift
//  SwiftUI_05
//
//  Created by zhhz on 15/1/20.
//  Copyright (c) 2015年 zhhz. All rights reserved.
//

import UIKit

let reuseIdentifier = "Cell"

class CustomLayout: UICollectionViewLayout {
    
    //内容总区域大小，不是可见区域
    override func collectionViewContentSize() -> CGSize {
        return CGSizeMake(collectionView!.bounds.size.width, collectionView!.bounds.size.height)
    }
    
    override func layoutAttributesForElementsInRect(rect: CGRect) -> [AnyObject]? {
        var attributesArray = [AnyObject]()
        let cellCount = self.collectionView!.numberOfItemsInSection(0)
        
        for var i=0 ; i<cellCount;++i{
            var indexPath = NSIndexPath(forItem: i, inSection: 0)
            var attributes = self.layoutAttributesForItemAtIndexPath(indexPath)
            
            attributesArray.append(attributes)
        }
        return attributesArray
    }
    
    override func layoutAttributesForItemAtIndexPath(indexPath: NSIndexPath) -> UICollectionViewLayoutAttributes!{
        var attribute = UICollectionViewLayoutAttributes(forCellWithIndexPath: indexPath)
        
        let itemSpacing = 2
        let lineSpacing = 5
        
        let largeCellSide:Float = 200
        let smallCellSide:Float = 100
        
        var insets = UIEdgeInsetsMake(2, 5, 2, 5)
        
        var line:Int = indexPath.item/3
        
        var lineOriginY = largeCellSide * Float(line) + Float(lineSpacing*line) + Float(insets.top)
        
        var rightLargeX = Float(collectionView!.bounds.size.width) - Float(largeCellSide) - Float(insets.right)
        
        var rightSmallX = Float(collectionView!.bounds.size.width) - Float(smallCellSide) - Float(insets.right)
        
        if indexPath.item % 6 == 0{
            attribute.frame = CGRectMake(insets.left, CGFloat(lineOriginY), CGFloat(largeCellSide), CGFloat(largeCellSide))
        }else if indexPath.item % 6 == 1{
            attribute.frame = CGRectMake(CGFloat(rightSmallX),CGFloat(lineOriginY),CGFloat(smallCellSide),CGFloat(smallCellSide))
        }else if indexPath.item % 6 == 2{
            attribute.frame = CGRectMake(CGFloat(rightSmallX), CGFloat(Float(lineOriginY) + Float(smallCellSide) + Float(insets.top)), CGFloat(smallCellSide), CGFloat(smallCellSide))
        }else if indexPath.item % 6 == 3{
            attribute.frame = CGRectMake(insets.left,CGFloat(lineOriginY), CGFloat(smallCellSide), CGFloat(smallCellSide))
        }else if indexPath.item % 6 == 4{
            attribute.frame = CGRectMake(insets.left, CGFloat(Float(lineOriginY) + Float(smallCellSide) + Float(insets.top)), CGFloat(smallCellSide), CGFloat(smallCellSide))
        }else if indexPath.item % 6 == 5{
            attribute.frame = CGRectMake(CGFloat(rightLargeX), CGFloat(lineOriginY), CGFloat(largeCellSide), CGFloat(largeCellSide))
        }
        return attribute
    }
}

class CollectionViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource{

    var collectionView:UICollectionView!
    
    let courses = [["name":"Swift","pic":"Swift.png"],["name":"ObjectC","pic":"ObjectC.png"],["name":"java","pic":"java.png"],["name":"php","pic":"php.png"]]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        let layout = CustomLayout()
        
        self.collectionView = UICollectionView(frame: CGRectMake(0, 20, view.bounds.size.width, view.bounds.height-20),collectionViewLayout:layout)
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        self.collectionView.registerClass(UICollectionViewCell.self, forCellWithReuseIdentifier: "ViewCell")
        
        self.collectionView.backgroundColor = UIColor.whiteColor()
        self.title = "dada"
        self.view.addSubview(collectionView)
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        

        // Do any additional setup after loading the view.
    }

    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        //#warning Incomplete method implementation -- Return the number of sections
        return 1
    }


    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //#warning Incomplete method implementation -- Return the number of items in the section
        return courses.count
    }

    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let identify:String = "ViewCell"
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(identify ,forIndexPath: indexPath) as UICollectionViewCell
        let img = UIImageView(image: UIImage(named: courses[indexPath.item]["pic"]!))
        img.frame = cell.bounds
        
        let label = UILabel(frame: CGRectMake(0, 5, cell.bounds.size.width, 20))
        label.textAlignment = NSTextAlignment.Center
        label.text = courses[indexPath.item]["name"]
        cell.addSubview(img)
        cell.addSubview(label)
        // Configure the cell
    
        return cell
    }

    // MARK: UICollectionViewDelegate

    /*
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(collectionView: UICollectionView, shouldHighlightItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(collectionView: UICollectionView, shouldSelectItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    */

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(collectionView: UICollectionView, shouldShowMenuForItemAtIndexPath indexPath: NSIndexPath) -> Bool {
        return false
    }

    override func collectionView(collectionView: UICollectionView, canPerformAction action: Selector, forItemAtIndexPath indexPath: NSIndexPath, withSender sender: AnyObject?) -> Bool {
        return false
    }

    override func collectionView(collectionView: UICollectionView, performAction action: Selector, forItemAtIndexPath indexPath: NSIndexPath, withSender sender: AnyObject?) {
    
    }
    */

}
