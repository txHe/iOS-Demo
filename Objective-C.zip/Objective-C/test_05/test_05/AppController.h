//
//  AppController.h
//  test_05
//
//  Created by zhhz on 14-10-14.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppController : NSObject{
    IBOutlet NSTextField *textField;
    IBOutlet NSTextField *resultsField;
}

-(IBAction)uppercase:(id)sender;
-(IBAction)lowercase:(id)sender;
@end
