//
//  ViewController.m
//  Hello World
//
//  Created by zhhz on 14-10-15.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import "ViewController.h"



@implementation ViewController

@synthesize statusText;

-(IBAction)buttonPressed:(id)sender{
    NSString *title=[sender titleForState:UIControlStateNormal];//
    NSString *newText=[[NSString alloc] initWithFormat:@"%@ button pressed.",title];
    statusText.text=newText;
}

-(void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}

@end
