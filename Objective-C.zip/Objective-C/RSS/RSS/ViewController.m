//
//  ViewController.m
//  RSS
//
//  Created by zhhz on 14/11/27.
//  Copyright (c) 2014年 zhhz. All rights reserved.
//

#import "ViewController.h"

#define kURL @"http://ww1.sinaimg.cn/mw1024/73be18f6gw1emphpxxw5kj20dc0fgwez.jpg"
#define kurl @"http://i1.hoopchina.com.cn/blogfile/201411/26/BbsImg141695166193052_524*344.png"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UIButton *button1;

@end

@implementation ViewController

-(void)downloadImage:(NSString *) url{
    NSData *data = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:url]];
    UIImage *image=[[UIImage alloc] initWithData:data];
    if(image == nil)
    {
        
    }
    else
    {
        [self performSelectorOnMainThread:@selector(updateUI:) withObject:image waitUntilDone:YES];
    }
}

-(void)updateUI:(UIImage *)image{
    self.img.image =image;
}

-(IBAction)button:(id)sender{
    NSThread *thread1=[[NSThread alloc] initWithTarget:self selector:@selector(downloadImage:) object:kurl];
    //[thread1 performSelectorOnMainThread:@selector(updateUI:) withObject:image waitUntilDone:YES];
    [thread1 start];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(downloadImage:) object:kURL];
    //[thread start];
    dispatch_queue_t mainQueue  =dispatch_get_main_queue();
    dispatch_queue_t imageDownloadQueue=dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(imageDownloadQueue, ^{
        NSError *err=nil;
        NSURL *urlImg=[NSURL URLWithString:@"http://i3.hoopchina.com.cn/blogfile/201411/27/BbsImg141705035785994_640*960.jpg"];
        NSData *data=[[NSData alloc] initWithContentsOfURL:urlImg options:NSDataReadingMappedAlways error:&err];
        UIImage *img=[UIImage imageWithData:data];
        if(img){
            dispatch_async(mainQueue, ^{
                self.img.image=img;
            });
        }
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
